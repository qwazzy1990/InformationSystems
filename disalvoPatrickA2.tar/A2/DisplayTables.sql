SELECT * FROM  Topics;
SELECT * FROM Projects;
SELECT * FROM Reports;
SELECT * FROM FundingAgencies;
SELECT * FROM Grants;
SELECT * FROM Researchers;