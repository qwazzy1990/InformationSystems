DROP TABLE Projects;
DROP TABLE Topics;
DROP TABLE Reports;
DROP TABLE FundingAgencies;
DROP TABLE Grants;
DROP TABLE Researchers;
